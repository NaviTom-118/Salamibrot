/**
 * Configuration file for the Salamibrot Minecraft bot
 */
module.exports = {
  // Minecraft server details
  server: {
    host: 'xxAll.aternos.me',
    port: 58774,
    version: '1.19.4' // Change this to match the server version if needed
  },
  
  // Bot details
  bot: {
    username: 'Salamibrot',
    auth: 'offline' // Use 'microsoft' for premium accounts
  },
  
  // Connection settings
  connection: {
    reconnectDelay: 5000, // Time in ms to wait before reconnecting
    maxRetries: -1 // Maximum number of reconnection attempts (-1 for infinite)
  }
};
