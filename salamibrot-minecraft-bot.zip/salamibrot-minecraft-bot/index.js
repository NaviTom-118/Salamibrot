/**
 * Salamibrot - A simple Minecraft bot
 * 
 * This bot connects to a specified Minecraft server and maintains
 * the connection. It uses the Mineflayer library for Minecraft
 * interaction functionality.
 */

// Import the mineflayer library
const mineflayer = require('mineflayer');

// Import configuration
const config = require('./config.js');

// Variables
let bot;
let retryCount = 0;

/**
 * Creates and connects the Minecraft bot
 */
function createBot() {
  console.log(`Connecting to ${config.server.host}:${config.server.port} as ${config.bot.username}...`);
  
  // Create the bot instance
  bot = mineflayer.createBot({
    host: config.server.host,
    port: config.server.port,
    username: config.bot.username,
    auth: config.bot.auth,
    version: config.server.version
  });

  // Setup event handlers
  setupEventHandlers();
}

/**
 * Set up event handlers for the bot
 */
function setupEventHandlers() {
  // Fired when the bot spawns in the game
  bot.on('spawn', () => {
    console.log(`✅ Successfully connected to the server as ${config.bot.username}`);
    retryCount = 0; // Reset retry counter on successful connection
    
    // Optional: You can add additional actions here that the bot should do upon joining
  });

  // Fired when the bot is kicked from the server
  bot.on('kicked', (reason) => {
    console.log(`❌ Bot was kicked from the server for: ${reason}`);
    attemptReconnect();
  });

  // Fired when the bot is disconnected from the server
  bot.on('end', () => {
    console.log('❌ Disconnected from the server');
    attemptReconnect();
  });

  // Fired when an error occurs
  bot.on('error', (err) => {
    console.error(`❌ Error occurred: ${err.message}`);
    // The 'end' event will be triggered after an error
  });

  // Optional: Handle chat messages
  bot.on('chat', (username, message) => {
    // Ignore messages from the bot itself
    if (username === bot.username) return;
    
    console.log(`[CHAT] ${username}: ${message}`);
    
    // You can add simple command handling here if needed
    // For example, respond to "!ping" with "pong"
    if (message === '!ping') {
      bot.chat('pong');
    }
  });
}

/**
 * Attempt to reconnect to the server
 */
function attemptReconnect() {
  // Check if we've reached the maximum number of retries
  if (config.connection.maxRetries !== -1 && retryCount >= config.connection.maxRetries) {
    console.log('❌ Maximum reconnection attempts reached. Giving up.');
    return;
  }

  retryCount++;
  
  // Add a progressive delay for reconnection attempts to avoid server throttling
  // This increases the delay for each consecutive attempt
  const currentDelay = config.connection.reconnectDelay * (1 + Math.min(retryCount / 10, 6));
  
  console.log(`Attempting to reconnect in ${Math.round(currentDelay / 1000)} seconds... (Attempt ${retryCount})`);
  
  // Schedule a reconnection attempt
  setTimeout(() => {
    createBot();
  }, currentDelay);
}

// Start the bot
createBot();

// Handle script termination
process.on('SIGINT', () => {
  console.log('Bot is shutting down...');
  if (bot) {
    bot.quit();
  }
  process.exit(0);
});
