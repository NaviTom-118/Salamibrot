# Salamibrot Minecraft Bot

Ein einfacher Minecraft-Bot, der sich mit einem bestimmten Aternos-Server verbindet.

## Features

- Verbindet sich mit einem Minecraft-Server (Aternos)
- Bleibt verbunden und versucht bei Unterbrechungen, die Verbindung wiederherzustellen
- Unendliche Verbindungsversuche mit progressiver Verzögerung
- Minimaler Ressourcenverbrauch
- Einfach zu konfigurieren

## Anforderungen

- Node.js (v12 oder neuer)
- NPM (kommt mit Node.js)

## Installation und Nutzung auf GitHub

1. Repository auf GitHub erstellen:
   - Erstelle ein neues Repository auf GitHub
   - Wähle einen Namen (z.B. "salamibrot-minecraft-bot")

2. Dateien hochladen:
   - Lade die folgenden Dateien in dein Repository hoch:
     - `index.js`
     - `config.js`
     - `README.md`
     - `package.json` (falls vorhanden)

3. Lokales Klonen und Ausführen:
   ```
   git clone https://github.com/dein-username/salamibrot-minecraft-bot.git
   cd salamibrot-minecraft-bot
   npm install mineflayer
   node index.js
   ```

## Server-Konfiguration

Die Server-Einstellungen kannst du in der `config.js` Datei anpassen:

```javascript
module.exports = {
  // Minecraft server details
  server: {
    host: 'xxAll.aternos.me',  // Deine Server-Adresse
    port: 58774,               // Dein Server-Port
    version: '1.19.4'          // Minecraft-Version des Servers
  },
  
  // Bot details
  bot: {
    username: 'Salamibrot',    // Name des Bots
    auth: 'offline'            // 'offline' für Nicht-Premium-Accounts
  },
  
  // Connection settings
  connection: {
    reconnectDelay: 5000,      // Basis-Verzögerung zwischen Verbindungsversuchen (in ms)
    maxRetries: -1             // -1 für unendliche Verbindungsversuche
  }
};
   